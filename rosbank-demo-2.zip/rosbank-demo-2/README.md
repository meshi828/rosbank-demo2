# ROSBANK Demo 2 — Mock Online Bank (Node.js + Express + TypeScript)

Второй вариант демо-репозитория — на Node.js + Express + TypeScript. Лёгкий, локальный, готов показать другу: регистрация/логин (JWT), счёта, перевод между своими счетами, простая симуляция СБП и вебхуки.

## Возможности
- Express + TypeScript
- JWT-аутентификация
- Хранилище: lowdb (JSON-файл) — без зависимостей на СУБД
- Эндпоинты: /auth, /accounts, /payments, /webhooks
- Тесты: jest + supertest
- Скрипты для разработки и запуска через ts-node-dev

## Быстрый старт
```bash
# Установи зависимости
npm install
# Запуск dev сервера
npm run dev
# Собрать и запустить
npm run build
npm start
```
API доступен по умолчанию на http://localhost:3000

Примечание: это учебный проект, не для продакшена.
