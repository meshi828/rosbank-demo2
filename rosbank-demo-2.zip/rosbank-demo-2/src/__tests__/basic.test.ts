import request from "supertest";
import app from "../index";

describe("smoke", () => {
  it("root", async () => {
    const r = await request(app).get("/");
    expect(r.status).toBe(200);
    expect(r.body.name).toBeDefined();
  });
});
