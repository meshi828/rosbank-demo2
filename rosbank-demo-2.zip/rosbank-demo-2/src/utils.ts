import jwt from "jsonwebtoken";
import { SECRET = 'supersecret' } from process.env;
import bcrypt from "bcryptjs";

export function hash(password: string){ return bcrypt.hashSync(password, 8); }
export function verify(password: string, hash: string){ return bcrypt.compareSync(password, hash); }

export function createToken(payload: object, expiresIn = '1h'){
  return jwt.sign(payload as any, SECRET, { expiresIn });
}

export function verifyToken(token: string){
  try{
    return jwt.verify(token, SECRET) as any;
  }catch(e){
    return null;
  }
}
