import express from "express";
import { db } from "../storage";
import { requireAuth } from "../middleware/auth";
import { nanoid } from "nanoid";

const router = express.Router();

function evaluateRules(amount: number, channel: string, to: string){
  const reasons: string[] = [];
  if (amount > 300000) reasons.push("amount_over_limit");
  if (channel === "sbp" && !to.startsWith("+7")) reasons.push("sbp_requires_russian_phone");
  return reasons;
}

router.post("/", requireAuth, async (req, res) => {
  const { fromAccountId, to, channel, amount } = req.body;
  await db.read();
  const account = db.data!.accounts.find(a => a.id === fromAccountId);
  const userId = req.user.sub;
  if (!account || account.userId !== userId) return res.status(404).json({ error: "Account not found" });
  if (account.balance < amount) return res.status(400).json({ error: "Insufficient funds" });
  const reasons = evaluateRules(amount, channel, to);
  if (reasons.length) return res.status(403).json({ error: "Fraud check failed", reasons });
  // process
  account.balance -= amount;
  const payment = { id: nanoid(), userId, fromAccountId, to, channel, amount, status: "succeeded", receipt: channel === "sbp" ? `RRN-${nanoid(6)}` : "OK" };
  db.data!.payments.push(payment as any);
  await db.write();
  res.json(payment);
});

router.get("/", requireAuth, async (req, res) => {
  await db.read();
  const userId = req.user.sub;
  const payments = db.data!.payments.filter(p => p.userId === userId);
  res.json(payments);
});

export default router;
