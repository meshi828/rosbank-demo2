import express from "express";
import { db } from "../storage";
import { requireAuth } from "../middleware/auth";

const router = express.Router();

router.get("/", requireAuth, async (req, res) => {
  await db.read();
  const userId = req.user.sub;
  const accounts = db.data!.accounts.filter(a => a.userId === userId);
  // add mock external bank accounts if none present
  if (!accounts.some(a => a.iban.includes("SBER"))){
    accounts.push({ id: "sber1", userId, iban: "RU00SBER00000000000002", balance: 50000, currency: "RUB" } as any);
  }
  res.json(accounts);
});

export default router;
