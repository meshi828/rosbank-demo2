import express from "express";
import fetch from "node-fetch"; // node-fetch v2 compatibility note
import { requireAuth } from "../middleware/auth";
import { db } from "../storage";

const router = express.Router();

router.post("/", requireAuth, async (req, res) => {
  const { url, event, data } = req.body;
  // try send (simple, no retries)
  try {
    await fetch(url, { method: "POST", body: JSON.stringify({ event, data }), headers: { "Content-Type": "application/json" } });
    return res.json({ status: "delivered" });
  } catch (e) {
    return res.status(502).json({ status: "failed" });
  }
});

export default router;
