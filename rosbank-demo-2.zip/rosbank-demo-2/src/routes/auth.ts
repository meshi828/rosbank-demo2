import express from "express";
import { db } from "../storage";
import { nanoid } from "nanoid";
import { hash, createToken, verify } from "../utils";

const router = express.Router();

router.post("/register", async (req, res) => {
  const { email, password } = req.body;
  await db.read();
  if (db.data!.users.find(u => u.email === email)) return res.status(400).json({ error: "Email exists" });
  const id = nanoid();
  const passwordHash = hash(password);
  db.data!.users.push({ id, email, passwordHash, isAdmin: false });
  // create default account
  db.data!.accounts.push({ id: nanoid(), userId: id, iban: `RU00LOCAL${id.slice(0,8)}`, balance: 10000, currency: "RUB" });
  await db.write();
  res.json({ id, email });
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  await db.read();
  const user = db.data!.users.find(u => u.email === email);
  if (!user || !verify(password, user.passwordHash)) return res.status(400).json({ error: "Invalid credentials" });
  const token = createToken({ sub: user.id, email: user.email });
  res.json({ access_token: token, token_type: "bearer" });
});

export default router;
