import express from "express";
import bodyParser from "body-parser";
import authRouter from "./routes/auth";
import accountsRouter from "./routes/accounts";
import paymentsRouter from "./routes/payments";
import webhooksRouter from "./routes/webhooks";
import { initDb } from "./storage";

const app = express();
app.use(bodyParser.json());

initDb(); // ensure DB file exists with defaults

app.use("/auth", authRouter);
app.use("/accounts", accountsRouter);
app.use("/payments", paymentsRouter);
app.use("/webhooks", webhooksRouter);

app.get("/", (req, res) => res.json({ name: "ROSBANK Demo 2", docs: "/docs (not implemented)" }));

const port = process.env.PORT || 3000;
if (process.env.NODE_ENV !== "test") {
  app.listen(port, () => console.log(`Server listening on ${port}`));
}

export default app;
