import { Low } from 'lowdb';
import { JSONFile } from 'lowdb/node';
import path from 'path';
import { fileURLToPath } from 'url';
import { join } from 'path';
import fs from 'fs';

type User = { id: string; email: string; passwordHash: string; isAdmin?: boolean };
type Account = { id: string; userId: string; iban: string; balance: number; currency: string };
type Payment = { id: string; userId: string; fromAccountId: string; to: string; channel: string; amount: number; status: string; receipt?: string };

const DB_PATH = path.join(process.cwd(), 'db.json');
const adapter = new JSONFile<{ users: User[]; accounts: Account[]; payments: Payment[] }>(DB_PATH);
export const db = new Low(adapter);

export async function initDb(){ 
  if (!fs.existsSync(DB_PATH)){
    await db.read();
    db.data = { users: [], accounts: [], payments: [] };
    await db.write();
  } else {
    await db.read();
    db.data = db.data || { users: [], accounts: [], payments: [] };
  }
}
